import numpy as np

def deepwalk_based_edgeSampling(A, nodes, num_walks, walk_length, window_size):

    walks = []


    for nodeIndx,node in enumerate(nodes):
        for i in range(num_walks):
            walk = [nodeIndx]
            current_node = nodeIndx
            for j in range(walk_length-1):
                neighbors = np.where(A[current_node,:] != 0)[0]
                if len(neighbors) > 0:
                    next_node = np.random.choice(neighbors)
                else:
                    next_node = nodeIndx
                walk.append(next_node)
                current_node = next_node
            walks.append(walk)

    pairs = []
    for walk in walks:
        for i in range(len(walk)):
            for j in range(i+1, min(i+window_size, len(walk))):
                pairs.append((walk[i], walk[j]))

    X = []
    Y = []
    for pair in pairs:
        X.append(pair[0])
        Y.append(pair[1])


    return zip(X, Y)

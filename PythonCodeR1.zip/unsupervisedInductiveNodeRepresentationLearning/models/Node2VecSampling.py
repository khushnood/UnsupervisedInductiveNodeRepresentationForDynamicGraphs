import networkx as nx
import numpy as np

def node2vec_edge_sampling(graph, num_walks, walk_length, p, q):
    # Generate random walks
    walks = generate_random_walks(graph, num_walks, walk_length)

    # Extract edges from random walks
    node_index = {node: i for i, node in enumerate(graph.nodes)}
    edges = []
    for walk in walks:
        for i in range(len(walk) - 1):
            from_node = walk[i]
            to_node = walk[i + 1]
            edges.append([node_index[from_node], node_index[to_node]])

    return edges

def generate_random_walks(graph, num_walks, walk_length):
    walks = []
    for _ in range(num_walks):
        for node in graph.nodes():
            walk = random_walk(graph, walk_length, start_node=node)
            walks.append(walk)
    return walks

def random_walk(graph, walk_length, start_node=None):
    if start_node is None:
        start_node = np.random.choice(graph.nodes())
    walk = [start_node]
    while len(walk) < walk_length:
        current_node = walk[-1]
        next_node = choose_next_node(graph, current_node)
        walk.append(next_node)
    return walk

def choose_next_node(graph, current_node, p=1, q=1):
    neighbors = list(graph.neighbors(current_node))
    if len(neighbors) == 0:
        return current_node
    if len(neighbors) == 1:
        return neighbors[0]

    if np.random.rand() < p:
        # Choose uniformly
        return np.random.choice(neighbors)
    else:
        # Choose based on proximity
        weights = []
        for neighbor in neighbors:
            if neighbor == current_node:
                weights.append(1 / p)
            elif graph.has_edge(current_node, neighbor):
                weights.append(1)
            else:
                weights.append(1 / q)
        weights /= np.sum(weights)
        return np.random.choice(neighbors, p=weights)

if __name__ == '__main__':


    # Example usage:
    # Create a graph (you can replace this with your graph)
    graph = nx.Graph()
    graph.add_edges_from([(1, 2), (2, 3), (3, 4), (4, 1)])

    # Generate edge list using node2vec edge sampling
    edge_list = node2vec_edge_sampling(graph, num_walks=10, walk_length=4, p=1, q=1)
    print(edge_list)

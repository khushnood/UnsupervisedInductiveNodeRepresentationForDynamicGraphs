import numpy as np

def hebbian_embedding(adjacency_matrix, d):
    """
    Hebbian-based node embedding.

    Parameters:
    adjacency_matrix : numpy.ndarray
        Adjacency matrix of the graph.
    d : int
        Dimensionality of the node embeddings.

    Returns:
    numpy.ndarray
        Node embeddings of shape (num_nodes, d).
    """

    num_nodes = adjacency_matrix.shape[0]
    # Initialize weight matrix randomly
    weights = np.random.randn(num_nodes, d)

    # Learning rate
    lr = 0.1

    # Number of iterations
    epochs = 100

    # Hebbian learning
    for _ in range(epochs):
        for i in range(num_nodes):
            for j in range(num_nodes):
                if i != j and adjacency_matrix[i][j] == 1:
                    weights[i] += lr * weights[j]

    return weights

# Example usage:
adj_matrix = np.array([[0, 1, 1],
                       [1, 0, 1],
                       [1, 1, 0]])
embedding_dimension = 2
node_embeddings = hebbian_embedding(adj_matrix, embedding_dimension)
print(f'adjacency matrix: {adj_matrix}')
print(node_embeddings)
print(f'similarityScore matrix: {node_embeddings.dot(node_embeddings.T)}')

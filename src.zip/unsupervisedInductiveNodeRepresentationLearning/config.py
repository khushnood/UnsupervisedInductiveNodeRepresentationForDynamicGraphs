import platform
from os.path import join
from datetime import datetime
from utils.consts import TLP, NC

experiment_name = 'unsupervised_withSampling'
time_now = datetime.now().strftime('%y%m')
params = {
'results_path': join(r"../results", f"{platform.node()}_{time_now}_{experiment_name}"),

'datasets': {'DPPIN-Lambert'},
'dataset': 'MITC',
'task': TLP,
'test_size': 0.2,
'train_skip': 100,  # down sample the training set
'model_name':'',
'all_models':{'dgnn'},


'keras_args':
    {'batch_size': 64,
     'nb_epoch': 10,
     'nb_worker': 4}
}

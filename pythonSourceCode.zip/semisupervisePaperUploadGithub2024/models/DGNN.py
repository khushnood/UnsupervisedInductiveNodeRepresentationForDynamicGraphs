import os
from os.path import join

import networkx as nx

import numpy as np
from tqdm import tqdm

import scipy.sparse as sp
from keras import regularizers
from keras.layers import Input,  GRU, Dense, Activation, Concatenate, Lambda
from keras.models import Model
#from numba import jit
#import cupy as cp
import loader
from models.task_model import TaskModel
from utils.graph_utils import get_graph_T, get_pivot_time, get_graph_times, multigraph2graph
from utils.general_utils import load_object, save_object
from utils.consts import TLP
from utils.TimeEmbed import TimeEncode,Time2Vec
import torch
from models.Node2VecSampling import node2vec_edge_sampling
from models.deepWalkSampling import deepwalk_based_edgeSampling
from procrustes import rotational
from plots import visualizeEmbedding
class DGNN(TaskModel):
    def __init__(self, graph_nx, task, dump_folder, test_size=0, align=True,model_name='prone'):
        '''

        Args:
            graph_nx: networkx - holding the temporal graph
            task: str - name of the task. either 'temporal_link_prediction' or 'node_classification'
            dump_folder: string - link to a dump folder of the graph dataset, in order for future runs to run faster
            test_size: folat - the wanted size of test_size
            align: bool - True if alignment is wanted, else False

        '''
        super(DGNN, self).__init__(task=task)

        self.dump_folder = dump_folder
        self.test_size = test_size
        self.align = align

        self.model_name=model_name

        self.graph_nx = graph_nx
        times = get_graph_times(self.graph_nx)

        if self.task == TLP:
            self.pivot_time = self.calculate_pivot_time()
        else:
            self.pivot_time = times[-1]

        self.train_time_steps = times[times <= self.pivot_time]

        # initialize
        self.graph_nx = self.initialize()

    def get_dataset(self, train_skip=1):
        '''
        This function is responsible of creating the dataset of the wanted task from the given graph_nx. Wraps the
        function 'task_loader.load_task' for caching.
        Args:
            train_skip: float - ratio of the data we take for train. For example, if we have N possible
                                 samples in the given graph_nx, then we take only int(N/train_skip) samples for train.
                                 This is highly important in large graphs.
        Returns:
            X: dict - with keys 'train', 'test'. each value is a np.array of the dataset, where each entery is a sample
                      with the embeddings.
            y: dict - with keys 'train', 'test', each value is a np.array of the dataset, where y[key][i] is the label
                      of X[key][i] for the given task.
        '''
        # load task data
        task_data_path = join(self.dump_folder, f'{self.task}_dataset_{self.pivot_time}.data')
        if os.path.exists(task_data_path):
            X, y = load_object(task_data_path)
        else:
            X, y = loader.load_task(self.graph_nx, self.task, train_skip=1, pivot_time=self.pivot_time,
                                    test_size=self.test_size)
            save_object((X, y), task_data_path)

        X = {'train': X['train'][::train_skip], 'test': X['test']}
        y = {'train': y['train'][::train_skip], 'test': y['test']}

        return X, y

    @staticmethod
    def _get_model(task, input_shape, latent_dim=128, num_classes=1):
        '''
        Given the task, return the desired architecture of training
        Args:
            task: string - of the tasks name, either 'temporal_link_prediction' or 'node_classification'
            input_shape: tuple - shape of a singe sample
            latent_dim: int - the size of the LSTM latent space
            num_classes: int - number of classes. Relevant only if task=='node_classification'
        Returns:
            keras model of DGNN
        '''
        if task == TLP:

            inputs = Input(shape=input_shape)

            lmda_lyr1 = Lambda(lambda x: x[:, 0, :, :], output_shape=input_shape[1:])(inputs)
            lmda_lyr2 = Lambda(lambda x: x[:, 1, :, :], output_shape=input_shape[1:])(inputs)

            gru_lyr_siamese = GRU(latent_dim, return_sequences=False, activation='tanh',dropout=0.2)


            lstm_lyr1 = gru_lyr_siamese(lmda_lyr1)
            lstm_lyr2 = gru_lyr_siamese(lmda_lyr2)

            concat_lyr = Concatenate(axis=-1)([lstm_lyr1, lstm_lyr2])

            fc_lyr1 = Dense(latent_dim, activation='tanh',kernel_regularizer=regularizers.l2(0.01))(concat_lyr)

            fc_lyr2 = Dense(1)(fc_lyr1)
            soft_lyr = Activation('sigmoid')(fc_lyr2)

            model = Model(inputs, soft_lyr)

            model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
        else:
            raise Exception('unknown task for _get_model')
        return model

    def calculate_pivot_time(self):
        '''
        Calculate the pivot time that is needed in order to create a 'time_split_ratio' between train edges and
        test edges
        Returns:
            time step representing the pivot time step
        '''
        ratio2pivot = {}
        ratio2pivot_path = join(self.dump_folder, 'ratio2pivot.dict')
        if os.path.exists(ratio2pivot_path):
            ratio2pivot = load_object(ratio2pivot_path)
            if self.test_size in ratio2pivot:
                return ratio2pivot[self.test_size]
        pivot_time = get_pivot_time(self.graph_nx, self.test_size)
        ratio2pivot[self.test_size] = pivot_time
        save_object(ratio2pivot, ratio2pivot_path)
        return pivot_time

    def initialize(self):
        '''
        initialize the model by calculating embeddings per each time step and aligning them all together
        Returns:
            initialized netwrokx graph
        '''
        init_path = join(self.dump_folder, 'init.emb')
        if os.path.exists(init_path):
            graph_nx = nx.read_gpickle(init_path)
        else:

            if(self.model_name=='dgnn'):
                graph_nx = DGNN._initialize_embeddings_HebbianImplementedDGNN(self.pivot_time,self.graph_nx, self.train_time_steps)

            else:
                graph_nx = DGNN._initialize_embeddings_static(self.pivot_time, self.graph_nx, self.train_time_steps, self.model_name)
            nx.write_gpickle(graph_nx, init_path)

        if self.align:

            graph_nx = DGNN._align_embeddings(graph_nx, self.train_time_steps)


        return graph_nx



    @staticmethod
    def _initialize_embeddings_HebbianImplementedDGNN(pivot_time,graph_nx, times=None):
        '''
        Given a graph, learn embeddings for all nodes in all time step. Attribute 'time' for each edge mast appear
        Args:
            graph_nx: networkx - the given graph
            times: list - of the times we want to work with, if None then calculates for all times in the graph


        Returns:
            graph_nx: networkx - but with attributes for each node for each time step of its embedding
        '''


        timestamps=nx.get_edge_attributes(graph_nx, 'time')
        output_dim_time_encode=64

        vals = np.fromiter(timestamps.values(), dtype=float)
        valstensor=torch.from_numpy(vals)
        valstensor=torch.reshape(valstensor,[1,vals.shape[0]])
        modelTimeEmbed =TimeEncode(output_dim_time_encode)
        timeEmbeddings=modelTimeEmbed(valstensor.float())
        timeEmbeddingsDict={}
        for indx in range(0,vals.shape[0]):
            emp=timeEmbeddings[0][indx]
            timeEmbeddingsDict[vals[indx]]=emp.detach().numpy()
        if times is None:
            times = get_graph_times(graph_nx)

        output_dim=64
        nodeFeatureMap=nx.get_node_attributes(graph_nx,"features") # see this is set in data loader section
        if not nodeFeatureMap:
            print("No node level features found")


        trainingTime=pivot_time
        trainingTime=np.random.choice(times)


        #
        final_graph_nx_t = get_graph_T(graph_nx, max_time=pivot_time)
        final_graph_nx = multigraph2graph(final_graph_nx_t)
        cur_graph_nx_t = get_graph_T(graph_nx, max_time=trainingTime)
        cur_graph_nx = multigraph2graph(cur_graph_nx_t)
        edge_sampling_strategy='deepwalk' #deepwalk,node2vec, None
        A_hat, Adj,features,edges = compute_A_hat_Adj(final_graph_nx, cur_graph_nx, nodeFeatureMap, trainingTime, pivot_time, output_dim,
                                                      is_RW_edge_sampling=edge_sampling_strategy)
        input_dim=features.shape[1]
        hidden_dim=64

        """
        Learning for one snapshot and then using the same parameters for generating embedding for other snapshots of the graph.
        """

        W_1,W_hidden1,W_out=initialize_weights(input_dim,hidden_dim,output_dim)
        is_adam_opt=True
        is_softmax_act=True
        is_concat=True

        if is_adam_opt:
            moments = initialize_moments([W_1, W_hidden1, W_out])


        alpha = 0.0005
        learning_rate = 0.0005
        num_iters = 300

        #edges = np.nonzero(Adj)
        for i in tqdm(range(num_iters), desc=f'epochs for learning single snapshot at time {trainingTime}', unit='epoch'):


            if is_softmax_act:
                H_1, temp1 = gnn_forward_softmax(A_hat, features, W_1)
                H_2, temp2 = gnn_forward_softmax(A_hat, H_1, W_hidden1)
                H_3, temp3 = gnn_forward_softmax(A_hat, H_2, W_out)
            else:
                H_1, temp1 = gcn_layer_relu(A_hat, features, W_1)
                H_2, temp2 = gcn_layer_relu(A_hat, H_1, W_hidden1)
                H_3, temp3 = gcn_layer_relu(A_hat, H_2, W_out)


            if is_concat:
                learnedNodeFeatures=np.concatenate([H_3,H_2,H_1], axis=1)
            else:
                learnedNodeFeatures=H_3
            dL_dH3 = np.zeros_like(learnedNodeFeatures)
            learnedNodeFeatures_T=learnedNodeFeatures.T
            for ind,edge in enumerate(edges):
                from_node, to_node = edge

                h = learnedNodeFeatures[from_node, :].dot(learnedNodeFeatures_T[:, to_node])
                e = 1 / (1 + np.exp(-h))
                #e=np.tanh(h)

                grad=e * (1- e)

                dL_dH3[from_node, :] += grad * (learnedNodeFeatures_T[:, to_node])
                dL_dH3[to_node,: ] +=  grad *(learnedNodeFeatures_T[:, from_node])


            if is_softmax_act:
                if is_concat:
                    dL_dH3 = dL_dH3[:, :temp3.shape[1]]
                    dL_dH3 = dL_dH3.dot((temp3).T).dot(1-(temp3))
                    dW_out = H_2.T.dot(dL_dH3)

                else:
                    dL_dH3 = dL_dH3.dot(temp3.T).dot(1-temp3)
                    dW_out = H_2.T.dot(dL_dH3)

                dL_dH2 = dL_dH3.dot(W_out.T)
                dL_dZ2 = dL_dH2.dot(temp2.T).dot(1 - temp2)
                dW_hidden1 = H_1.T.dot(dL_dZ2)

                dL_dH1 = dL_dZ2.dot(W_hidden1.T)
                dL_dZ1 = dL_dH1.dot(temp1.T).dot(1 - temp1)
                dW_1 = features.T.dot(dL_dZ1)

            else:

                if is_concat:
                    dL_dH3 = dL_dH3[:, :temp3.shape[1]]

                dX_2, dW_out = backward_gnn_layer_relu(dL_dH3, temp3, H_2, W_out)
                dX_1, dW_hidden1 = backward_gnn_layer_relu(dX_2, temp2, H_1, W_hidden1)
                _, dW_1 = backward_gnn_layer_relu(dX_1, temp1, features, W_1)

            

            if is_adam_opt:
                gradients = [dW_1, dW_hidden1, dW_out]
                parameters, moments=update_parameters_adam([W_1, W_hidden1, W_out], gradients, moments, learning_rate)
                W_1, W_hidden1, W_out=parameters
            else:
                W_out -= learning_rate * dW_out
                W_hidden1 -= learning_rate * dW_hidden1
                W_1 -= learning_rate * dW_1

            if (i+1)%100==0 and i + 1 != num_iters:

                trainingTime=np.random.choice(times)
                print(f"random training time changed to: {trainingTime}")
                A_hat, Adj,features,edges = compute_A_hat_Adj(final_graph_nx, cur_graph_nx, nodeFeatureMap, trainingTime, pivot_time, output_dim,
                                                              is_RW_edge_sampling=edge_sampling_strategy)


        for time in tqdm(times, desc='Inductively applying parameters for other snapshots', unit='time_step'):

            cur_graph_nx_1 = get_graph_T(graph_nx, max_time=time)
            cur_graph_nx = multigraph2graph(cur_graph_nx_1)
            A_hat, Adj,features,deepWalkEdgeSampled = compute_A_hat_Adj(final_graph_nx,cur_graph_nx,nodeFeatureMap, time, pivot_time,output_dim)



            if is_softmax_act:

                H_1, temp1 = gnn_forward_softmax(A_hat, features, W_1)
                H_2, temp2 = gnn_forward_softmax(A_hat, H_1, W_hidden1)
                H_3, temp3 = gnn_forward_softmax(A_hat, H_2, W_out)
            else:
                H_1, temp1 = gcn_layer_relu(A_hat, features, W_1)
                H_2, temp2 = gcn_layer_relu(A_hat, H_1, W_hidden1)
                H_3, temp3 = gcn_layer_relu(A_hat, H_2, W_out)

            learnedNodeFeaturestmp=H_3
            repeats_array_timeEmbed = np.tile(timeEmbeddingsDict.get(time), (learnedNodeFeaturestmp.shape[0], 1))

            if is_concat:
                embeddingWithTimePreviousConCat=np.concatenate([H_3,H_2,H_1], axis=1)
            else:
                embeddingWithTimePreviousConCat=H_3
            learnedNodeFeatures=np.concatenate([embeddingWithTimePreviousConCat,repeats_array_timeEmbed], axis=1)

            learnedNodeFeaturesDict = {node: np.asarray(learnedNodeFeatures[nodeIndx,:].flat) for nodeIndx, node in enumerate(cur_graph_nx.nodes())}

            nx.set_node_attributes(graph_nx, learnedNodeFeaturesDict, time)




        return graph_nx



    @staticmethod
    def _initialize_embeddings_static(pivot_time, graph_nx, times=None, model_name='prone'):
        '''

        :param pivot_time:
        :param graph_nx:
        :param times:
        :param model_name:

        :return:graph_nx to be implemented
        '''

        return graph_nx

    @staticmethod
    def _align_embeddings(graph_nx, times=None):
        '''
        Given a graph that went through 'initialize_embeddings', align all time step embeddings to one another
        Args:
            graph_nx: networkx - the given graph
            times: list - of the times we want to work with, if None then calculates for all times in the graph

        Returns:
            graph_nx: networkx - with aligned embeddings in its attributes for each node
        '''
        if times is None:
            times = get_graph_times(graph_nx)

        node2Q_t_1 = nx.get_node_attributes(graph_nx, times[0])
        Q_t_1 = np.array([node2Q_t_1[node] for node in node2Q_t_1])

        for time in times[1:]:
            node2Q_t = nx.get_node_attributes(graph_nx, time)
            Q_t = np.array([node2Q_t[node] for node in node2Q_t_1])

            result = rotational(Q_t, Q_t_1, scale=False, translate=False)
            R_t = result.t

            Q_t = np.array([node2Q_t[node] for node in node2Q_t])
            R_tQ_t = np.dot(Q_t, R_t)
            node2R_tQ_t = {node: vec for node, vec in zip(node2Q_t, R_tQ_t)}
            nx.set_node_attributes(graph_nx, node2R_tQ_t, time)
            node2Q_t_1 = node2R_tQ_t
            Q_t_1 = R_tQ_t

        return graph_nx




def gcn_layer(A_hat,  X, W):
    """

    :param A_hat:
    :param X:
    :param W:
    :return:
    """
    forward=A_hat.dot(X).dot(W)
    return forward

def gcn_layer_atn_prev(A_hat,  X, W):
    """

    :param A_hat:
    :param X:
    :param W:
    :return:
    """
    temp=softmax(X.dot(W),axis=1)
    forward=A_hat.dot(temp)
    return forward
def softmax(X):
    exp_X = np.exp(X - np.max(X, axis=1, keepdims=True))
    return exp_X / np.sum(exp_X, axis=1, keepdims=True)

def gcn_layer_relu(A_hat, X, W):
    #temp = softmax(X.dot(W))
    temp = np.maximum(0, X.dot(W))
    forward = A_hat.dot(temp)
    return forward, temp

def gnn_forward_softmax(A_hat, X, W):
    temp = softmax(X.dot(W))
    #temp = np.maximum(0, X.dot(W))
    forward = A_hat.dot(temp)
    return forward, temp

def backward_gnn_layer_relu(dout, temp, X, W):
    # Compute gradients with respect to the output of the ReLU activation
    d_temp = np.where(temp > 0, dout, 0)  # Gradient of loss with respect to temp

    # Compute gradients with respect to the input features (X)
    dX = d_temp.dot(W.T)  # Gradient of loss with respect to X

    # Compute gradients with respect to the weight matrix (W)
    dW = X.T.dot(d_temp)  # Gradient of loss with respect to W

    return dX, dW
def gcn_layer_torch(A_hat,  X, W):
    """

    :param A_hat:
    :param X:
    :param W:
    :return:
    """
    temp=torch.nn.functional.softmax(torch.mm(X, W), dim=1)
    forward = torch.mm(A_hat, temp)
    return forward


def softmax(X, theta = 1.0, axis = None):
    """
    Compute the softmax of each element along an axis of X.

    Parameters
    ----------
    X: ND-Array. Probably should be floats.
    theta (optional): float parameter, used as a multiplier
        prior to exponentiation. Default = 1.0
    axis (optional): axis to compute values along. Default is the
        first non-singleton axis.

    Returns an array the same size as X. The result will sum to 1
    along the specified axis.
    """
    X=np.array(X)
    # make X at least 2d
    y = np.atleast_2d(X)

    # find axis
    if axis is None:
        axis = next(j[0] for j in enumerate(y.shape) if j[1] > 1)

    # multiply y against the theta parameter,
    y = y * float(theta)

    # subtract the max for numerical stability
    y = y - np.expand_dims(np.max(y, axis = axis), axis)

    # exponentiate y
    y = np.exp(y)

    # take the sum along the specified axis
    ax_sum = np.expand_dims(np.sum(y, axis = axis), axis)

    # finally: divide elementwise
    p = y / ax_sum

    # flatten if X was 1D
    if len(X.shape) == 1: p = p.flatten()

    return p

def normalize_spectral(adj):
    """Symmetrically normalize adjacency matrix."""
    #adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt)

def softmax_rowwise(matrix):
    return np.exp(matrix) / np.sum(np.exp(matrix), axis=1)

def normalize_input(X):
    return X / np.linalg.norm(X, axis=0, keepdims=True)

# Initialize weights using He initialization
def initialize_weights(input_dim, hidden_dim, output_dim):
    W_1 = np.random.randn(input_dim, hidden_dim) * np.sqrt(2 / input_dim)
    W_hidden1 = np.random.randn(hidden_dim, hidden_dim) * np.sqrt(2 / hidden_dim)
    W_out = np.random.randn(hidden_dim, output_dim) * np.sqrt(2 / hidden_dim)
    return W_1, W_hidden1, W_out
def initialize_moments(parameters):
    """
    Initialize the moments (first and second) for Adam optimizer.

    Parameters:
    parameters : list
        List of parameter arrays.

    Returns:
    list
        List of moment arrays.
    """
    moments = []
    for param in parameters:
        moments.append({'m': np.zeros_like(param), 'v': np.zeros_like(param)})
    return moments

def update_parameters_adam(parameters, gradients, moments, learning_rate, beta1=0.9, beta2=0.999, epsilon=1e-8):
    """
    Update parameters using the Adam optimizer.

    Parameters:
    parameters : list
        List of parameter arrays.
    gradients : list
        List of gradient arrays.
    moments : list
        List of moment dictionaries.
    learning_rate : float
        Learning rate.
    beta1 : float, optional
        Exponential decay rate for the first moment estimates (default is 0.9).
    beta2 : float, optional
        Exponential decay rate for the second moment estimates (default is 0.999).
    epsilon : float, optional
        Small constant to prevent division by zero (default is 1e-8).
    """
    t = 0
    for param, grad, moment in zip(parameters, gradients, moments):
        t += 1
        moment['m'] = beta1 * moment['m'] + (1 - beta1) * grad
        moment['v'] = beta2 * moment['v'] + (1 - beta2) * (grad ** 2)
        m_hat = moment['m'] / (1 - beta1 ** t)
        v_hat = moment['v'] / (1 - beta2 ** t)
        param -= learning_rate * m_hat / (np.sqrt(v_hat) + epsilon)

    return parameters, moments

def compute_A_hat_Adj(final_graph_nx, cur_graph_nx, nodeFeatureMap, trainingTime, pivot_time, output_dim, is_RW_edge_sampling='deepwalk'):

    final_nodes = final_graph_nx.nodes()
    cur_nodes = cur_graph_nx.nodes()
    G1_sub = final_graph_nx.subgraph(final_nodes)
    G2_sub = cur_graph_nx.subgraph(cur_nodes)
    deg_G1 = dict(G1_sub.degree)
    deg_G2 = dict(G2_sub.degree)

    degree_gain = {node: deg_G2[node] - deg_G1[node] for node in cur_nodes}
    node_index = {node: i for i, node in enumerate(cur_nodes)}
    Adj = nx.adjacency_matrix(G2_sub, nodelist=cur_nodes).toarray()
    degree_gain_vector = np.zeros(Adj.shape[0])
    for node, deg_gain in degree_gain.items():
        node_idx = node_index[node]
        degree_gain_vector[node_idx] = deg_gain

    #constToavoidZeroError = 1
    delta_t = pivot_time  - trainingTime
    delta_t=np.ones_like(degree_gain_vector)*delta_t

    rate = np.where(degree_gain_vector != 0, delta_t / (degree_gain_vector + 1e-8), 0)

    I = np.eye(Adj.shape[0])

    if is_RW_edge_sampling=='deepwalk':
        deepWalkEdgeSamples=deepwalk_based_edgeSampling(Adj,cur_nodes,num_walks=10, walk_length=80, window_size=5)
    elif is_RW_edge_sampling=='node2vec':
        deepWalkEdgeSamples=node2vec_edge_sampling(cur_graph_nx, num_walks=10, walk_length=80, p=1, q=1)

    else:
        deepWalkEdgeSamples=zip(*np.nonzero(Adj))
    nodeWiseIntensities = np.exp(-rate)
    A_hat = Adj + I
    A_hat = np.multiply(A_hat, nodeWiseIntensities[:, np.newaxis])
    nodeArrays = np.asarray(cur_nodes)
    if  nodeFeatureMap:
         features=np.zeros(shape=[Adj.shape[0],np.array(nodeFeatureMap.get(nodeArrays[0])).shape[0]])
         for nodeIndx,node in enumerate(cur_nodes):
             features[nodeIndx]=np.array(nodeFeatureMap.get(node))
    else:
        features = np.random.randn(Adj.shape[0], output_dim)

    features=normalize_input(features)


    return A_hat, Adj, features,(deepWalkEdgeSamples)


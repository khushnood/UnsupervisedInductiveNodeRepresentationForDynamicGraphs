# TempNodeEmbed
**
Unsupervised node embedding generation for dynamic graphs
**. 

Please extract the files in the same directory and run the main.py.
 
**Keywords**: DynamicNodeEmbedding, GraphRepresentationLearning, Dynamic Protein-protein interaction prediction, Protein embedding generation. 
## Please cite the following paper if you use this code. 

**Requirements**
pip install 
pthon>=3.6 
pip install networkx==2.3 tensorflow==1.14.0 qc-procrustes numpy==1.19.5 tqdm==4.40.0 pandas==1.3.2 Keras==2.3.1 matplotlib==3.5.2 torch==1.9.0 node2vec==0.4.3 sklearn==0.0

----
